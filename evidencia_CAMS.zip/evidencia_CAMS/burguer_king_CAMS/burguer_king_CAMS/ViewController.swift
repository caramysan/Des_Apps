//
//  ViewController.swift
//  burguer_king_CAMS
//
//  Created by Carlos Mendizabal on 11/04/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Button: BotonUno!
    @IBAction func hueValueChanged(_ sender: Any) { }
    @IBAction func saturationValueChanged(_ sender: Any) { }
    @IBAction func brightnessValueChanged(_ sender: Any) { }


}

