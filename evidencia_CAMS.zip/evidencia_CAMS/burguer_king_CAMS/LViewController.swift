//
//  LViewController.swift
//  burguer_king_CAMS
//
//  Created by Carlos Mendizabal on 21/05/21.
//

import UIKit
import GoogleSignIn
import Firebase

class LViewController: UIViewController {
    
    @IBOutlet var signInButton: GIDSignInButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        GIDSignIn.sharedInstance().presentingViewController = self
        
        if GIDSignIn.sharedInstance()?.currentUser != nil
        {
            
        }
        else{
            GIDSignIn.sharedInstance()?.signIn()
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
