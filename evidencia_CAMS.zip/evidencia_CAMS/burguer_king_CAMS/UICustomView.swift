//
//  UICustomView.swift
//  burguer_king_CAMS
//
//  Created by Carlos Mendizabal on 12/04/21.
//

import UIKit
import MaterialComponents.MaterialBottomNavigation

class UICustomView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
